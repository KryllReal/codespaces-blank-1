// Theme Page Management

const THEME_STORAGE_KEY = 'antigravity-theme';
const DARK_MODE_KEY = 'antigravity-dark-mode';
const ANIMATIONS_KEY = 'antigravity-animations';
const REDUCED_MOTION_KEY = 'antigravity-reduced-motion';
const DEFAULT_THEME = 'light-orange';

// Initialize theme page
document.addEventListener('DOMContentLoaded', () => {
    initializeThemePage();
    setupThemeCards();
    setupDisplayToggles();
});

function initializeThemePage() {
    const savedTheme = localStorage.getItem(THEME_STORAGE_KEY) || DEFAULT_THEME;
    applyTheme(savedTheme);
    updateThemeUIState(savedTheme);
}

function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem(THEME_STORAGE_KEY, theme);
}

function updateThemeUIState(theme) {
    document.querySelectorAll('.theme-card').forEach(card => {
        const cardTheme = card.dataset.theme;
        const isActive = cardTheme === theme;
        card.classList.toggle('active', isActive);
        
        const btn = card.querySelector('.theme-btn');
        if (btn) {
            btn.textContent = isActive ? 'Selected' : 'Select';
        }
    });
}

function setupThemeCards() {
    document.querySelectorAll('.theme-card').forEach(card => {
        const btn = card.querySelector('.theme-btn');
        if (btn) {
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                const theme = card.dataset.theme;
                applyTheme(theme);
                updateThemeUIState(theme);
            });
        }
    });
}

function setupDisplayToggles() {
    // Dark mode toggle
    const darkModeToggle = document.getElementById('darkModeToggle');
    if (darkModeToggle) {
        const isDarkMode = localStorage.getItem(DARK_MODE_KEY) === 'true';
        darkModeToggle.checked = isDarkMode;
        
        darkModeToggle.addEventListener('change', (e) => {
            const isDark = e.target.checked;
            localStorage.setItem(DARK_MODE_KEY, isDark);
            
            const currentTheme = document.documentElement.getAttribute('data-theme') || DEFAULT_THEME;
            if (isDark) {
                // Switch to dark variant
                if (currentTheme.includes('light')) {
                    const darkTheme = currentTheme.replace('light-', 'dark-');
                    applyTheme(darkTheme);
                    updateThemeUIState(darkTheme);
                }
            } else {
                // Switch to light variant
                if (currentTheme.includes('dark')) {
                    const lightTheme = currentTheme.replace('dark-', 'light-');
                    applyTheme(lightTheme);
                    updateThemeUIState(lightTheme);
                }
            }
        });
    }

    // Animations toggle
    const animationsToggle = document.getElementById('animationsToggle');
    if (animationsToggle) {
        const enableAnimations = localStorage.getItem(ANIMATIONS_KEY) !== 'false';
        animationsToggle.checked = enableAnimations;
        
        animationsToggle.addEventListener('change', (e) => {
            const enabled = e.target.checked;
            localStorage.setItem(ANIMATIONS_KEY, enabled);
            document.documentElement.style.setProperty('--animations-enabled', enabled ? '1' : '0');
        });
    }

    // Reduced motion toggle
    const reducedMotionToggle = document.getElementById('reducedMotionToggle');
    if (reducedMotionToggle) {
        const reducedMotion = localStorage.getItem(REDUCED_MOTION_KEY) === 'true';
        reducedMotionToggle.checked = reducedMotion;
        
        reducedMotionToggle.addEventListener('change', (e) => {
            const enabled = e.target.checked;
            localStorage.setItem(REDUCED_MOTION_KEY, enabled);
            
            if (enabled) {
                document.documentElement.style.setProperty('--transition-duration', '0s');
            } else {
                document.documentElement.style.removeProperty('--transition-duration');
            }
        });
    }
}
