// Theme Management System

const THEME_STORAGE_KEY = 'antigravity-theme';
const DEFAULT_THEME = 'light-orange';

function initTheme() {
    const saved = localStorage.getItem(THEME_STORAGE_KEY) || DEFAULT_THEME;
    applyTheme(saved);
}

function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem(THEME_STORAGE_KEY, theme);
}

// Initialize on load
document.addEventListener('DOMContentLoaded', () => {
    initTheme();
});
